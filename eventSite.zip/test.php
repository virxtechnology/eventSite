<?php

echo "ça marche";

?>